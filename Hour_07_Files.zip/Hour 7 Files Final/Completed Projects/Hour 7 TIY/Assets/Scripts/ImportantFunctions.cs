using UnityEngine;
using System.Collections;

public class ImportantFunctions : MonoBehaviour
{
	// Use this for initialization
	void Start ()
	{
		print ("Start runs before an object Updates");
	}
	
	// Update is called once per frame
	void Update ()
	{
		print ("This is called once a frame");
	}
}
